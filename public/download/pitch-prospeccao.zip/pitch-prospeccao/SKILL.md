---
name: pitch-prospeccao
description: Constrói e audita pitches de prospecção fria (cold call, cold e-mail, DM de LinkedIn, WhatsApp, áudio) usando a estrutura gatilho + empacotamento, cujo objetivo é vender a reunião e não a solução. Use sempre que o usuário pedir pitch, abordagem, cold call, cold e-mail, script de prospecção, sequência de outbound, "como abordar essa empresa", primeira mensagem para um lead, ou colar um pitch existente pedindo opinião, revisão, crítica ou melhoria. Use também quando ele mencionar taxa de resposta baixa, "não tem interesse", lead frio, agendamento de reunião, ICP, ou quando descrever uma empresa-alvo e um decisor sem dizer explicitamente a palavra "pitch". Vale para B2B complexo, enterprise, consultoria e serviços.
---

# Pitch de prospecção: gatilho + empacotamento

## O problema que essa skill resolve

Toda operação comercial tem duas alavancas: gerar oportunidade e converter oportunidade em receita. A maioria dos times estuda obsessivamente a segunda e ignora a primeira. Sem pipeline suficiente, nenhuma técnica de fechamento resolve.

A venda fria raramente é perdida na negociação. Ela é perdida nos primeiros segundos, quando o prospect avalia uma única pergunta: **"o que eu ganho continuando essa conversa?"**

O pitch mediano responde errado porque fala do vendedor. "Somos uma empresa que faz X, gostaria de te apresentar nossa solução." O prospect não pediu isso e não tem contexto para querer.

O pitch que converte responde certo porque demonstra repertório sobre o negócio do prospect antes de mencionar qualquer solução, e depois oferece um compromisso curto que entrega valor mesmo se ele disser não.

## Os dois modos

Identifique qual dos dois o usuário está pedindo. Se estiver ambíguo, pergunte em uma linha.

**Modo GERAR**: ele descreve uma empresa-alvo, um decisor, um segmento ou um ICP e quer o pitch pronto. Siga as fases 1 a 3 abaixo.

**Modo AUDITAR**: ele cola um pitch, script, e-mail ou sequência já existente e quer avaliação. Aplique a rubrica de `references/auditoria.md`, depois reescreva. Não devolva só a nota: a reescrita é o entregável principal.

Frequentemente os dois se combinam: audite o que ele tem, mostre onde quebra e entregue a versão nova.

---

## Fase 1: pesquisa e repertório

Esta fase é o que separa quem consegue reunião de quem escuta "não tenho interesse". Não pule para o texto sem ela.

O vendedor mediano pesquisa cargo, número de funcionários e notícia recente. Isso não gera repertório, gera dado. Repertório é entender a mecânica do negócio a ponto de conseguir apontar onde ele provavelmente vaza dinheiro.

Levante, nesta ordem de prioridade:

1. **Como a empresa ganha dinheiro**, independentemente da sua solução. Qual a linha de receita principal, o ticket médio provável, o ciclo de venda, quem paga a conta.
2. **Qual o motor de crescimento**: vendas de campo, inside sales, PLG, canal, franquia, varejo, licitação. O motor define os gargalos possíveis.
3. **Onde o modelo vaza**: CAC alto, churn, ociosidade de equipe, retrabalho, estoque parado, inadimplência, dependência de poucos clientes, processo manual em volume.
4. **Qual o gargalo típico daquele porte e segmento**. Empresas parecidas têm problemas parecidos, e é isso que permite abrir uma conversa sem conhecer a empresa por dentro.
5. **Qual evento observável está acontecendo agora**: contratação em massa de um time específico, rodada, expansão geográfica, novo produto, troca de liderança, mudança regulatória, entrada em enterprise.
6. **Quem é o dono da dor**: qual métrica esse cargo defende e por qual número ele é cobrado.

Se você tiver acesso a busca web ou a MCPs de dados de empresa, use antes de escrever. Um pitch com fato verificável vale mais que três pitches genéricos. Se não tiver acesso, peça ao usuário os dois ou três fatos que faltam em vez de inventar. Nunca invente número, cliente, case ou resultado.

Fontes rápidas e o que cada uma revela estão em `references/pesquisa.md`. Consulte quando precisar de um roteiro de investigação mais fino ou quando o segmento for desconhecido.

**Regra de honestidade**: só afirme o que dá para sustentar. "Vi que vocês abriram cinco vagas de SDR" é verificável. "Sei que vocês estão perdendo 30% do pipeline" é chute e destrói a credibilidade na primeira réplica. Padrão de segmento se apresenta como padrão de segmento, não como diagnóstico da empresa.

---

## Fase 2: o gatilho

Função do gatilho: gerar identificação e provar repertório em uma ou duas frases. O prospect precisa pensar "isso é sobre mim" antes de saber quem você é.

O gatilho não menciona a sua empresa, seu produto, sua metodologia nem seu nome comercial. Ele descreve o mundo do prospect.

Cinco formatos que funcionam, detalhados com exemplos em `references/biblioteca.md`:

- **Movimento**: ancora em um evento observável. "Percebi que vocês estão estruturando a venda para enterprise."
- **Padrão de segmento**: ancora na conversa com pares. "Tenho conversado com operações de saúde do mesmo porte e apareceu um padrão."
- **Estágio**: ancora na transição de porte. "Empresas que saem de 50 para 200 pessoas costumam esbarrar no mesmo ponto."
- **Mecânica de receita**: prova que você entendeu como eles monetizam. "No modelo de vocês, a receita depende da taxa de reativação da base."
- **Contradição observável**: aponta um dado público que não fecha. Use com cuidado, funciona com decisor sênior e queima com o resto.

Critérios de um bom gatilho: cabe em duas frases, contém pelo menos um elemento específico daquela empresa ou daquele segmento, e poderia ser dito por alguém que trabalha no setor, não por alguém vendendo software.

---

## Fase 3: o empacotamento

Aqui está a mudança de mentalidade que muda a taxa de conversão: **o objetivo do primeiro contato é vender a reunião, não a solução**.

Quem empacota o pedido como compromisso de compra só consegue atenção de quem já decidiu comprar, e isso é uma fração pequena do mercado potencial. Em venda complexa, você entrega valor primeiro para conseguir a atenção, e só depois começa o processo comercial.

Todo empacotamento precisa dos quatro ingredientes:

1. **Entrega antecipada**: o que ele leva da conversa. Diagnóstico, benchmark, três padrões, um mapa de gargalos, um cálculo de perda.
2. **Compromisso curto e nomeado**: diga o número de minutos. 20 ou 30. "Um café" e "um bate-papo rápido" não são compromissos, são ambiguidade.
3. **Saída digna**: permissão explícita de não seguir. "Se ao final não fizer sentido, você sai com o diagnóstico e algumas ideias para aplicar internamente."
4. **Próximo passo único**: uma pergunta, uma ação. Duas opções de horário no máximo.

Cinco formatos de empacotamento, com exemplos prontos em `references/biblioteca.md`: diagnóstico de padrões, benchmark de segmento, mapa de gargalos por estágio, teardown do que já existe, cálculo de perda.

Continue sem citar produto. A solução aparece na reunião, depois do diagnóstico.

---

## Formato de saída

No modo GERAR, entregue nesta ordem:

1. **Repertório levantado**: 4 a 6 linhas com os fatos e hipóteses que sustentam o pitch, marcando o que é verificado e o que é hipótese de segmento. Isso permite ao usuário corrigir a base antes de usar o texto.
2. **O pitch no canal principal** que o usuário pediu. Se ele não disse o canal, pergunte ou entregue cold call e cold e-mail.
3. **Duas ou três variações de registro** quando fizer sentido: conciso, executivo, narrativo. O usuário costuma querer a versão mais curta, ofereça sem ele pedir.
4. **Adaptações de canal** se ele estiver montando sequência. Regras de tamanho e ritmo por canal em `references/canais.md`.
5. **Respostas às duas objeções mais prováveis** daquele contexto, no formato objeção seguida de resposta em uma frase.

No modo AUDITAR, entregue:

1. **Nota por critério** com uma linha de justificativa cada, usando a rubrica.
2. **O erro estrutural principal**, nomeado. Geralmente é um destes: fala do vendedor, pede compromisso de compra, ou não tem entrega antecipada.
3. **A reescrita**, no mesmo canal do original.
4. **O que testar primeiro** se ele quiser fazer teste A/B.

Se o entregável passar de umas poucas telas (sequência completa, playbook, vários segmentos), crie um arquivo e entregue com SendUserFile em vez de despejar tudo na conversa.

---

## Como escrever o texto do pitch

Restrições de estilo que valem para todo texto gerado por esta skill:

- Sem travessão em nenhuma hipótese. Use vírgula, dois pontos ou parênteses.
- Sem estrutura de contraste do tipo "não é X, é Y".
- Sem sequências de frases curtas em cadeia estilo copywriting. Elas soam artificiais e o prospect sente o script.
- Sem buzzword genérico: jornada, ruído, poderoso, incrível, disruptivo, alavancar, solução robusta, revolucionário.
- Sem superlativo sobre a própria empresa: líder de mercado, referência, especialista renomado.
- Linguagem de negócio direta. Números concretos quando existirem, silêncio quando não existirem.
- Escreva como alguém do setor falaria com um par, não como fornecedor falando com comprador.

Teste rápido antes de entregar: leia o pitch em voz alta. Se soar como material de marketing, reescreva. Se soar como uma pessoa competente comentando o negócio do outro, está pronto.

---

## Erros que aparecem em quase todo pitch ruim

- Abre com a própria empresa, o próprio nome ou a própria credencial.
- Pede 15 minutos "para conhecer nossa plataforma". Isso é compromisso de compra disfarçado.
- Personaliza no enfeite (elogia um post, cita o nome do CEO) mas não demonstra repertório sobre o negócio.
- Faz três perguntas de qualificação antes de ter conquistado atenção.
- Empacota valor que só existe depois da compra, em vez de valor que existe já na reunião.
- Usa dado inventado ou impreciso que não sobrevive a uma réplica.
- Termina com "faz sentido conversarmos?", que é uma pergunta cuja resposta padrão é não.

---

## Sequência mental completa

Pesquisa gera repertório. Repertório gera relevância. Relevância conquista atenção. Atenção compra a reunião. A reunião permite o diagnóstico. O diagnóstico constrói a necessidade. A necessidade vira receita.

Cada etapa só existe se a anterior foi feita. Quando um pitch falha, quase sempre a causa está uma ou duas etapas antes de onde parece estar.

---

## Arquivos de referência

- `references/pesquisa.md`: roteiro de investigação, fontes por tipo de sinal, gargalos típicos por porte e por modelo de negócio.
- `references/biblioteca.md`: banco de gatilhos e empacotamentos com exemplos completos, e comparações antes/depois.
- `references/auditoria.md`: rubrica de 8 critérios com escala, faixas de nota e diagnóstico por padrão de falha.
- `references/canais.md`: regras de tamanho, ritmo e assunto por canal, e desenho de sequência multicanal.

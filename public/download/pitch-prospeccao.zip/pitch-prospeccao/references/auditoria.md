# Rubrica de auditoria de pitch

Use quando o usuário colar um pitch, script, e-mail ou sequência existente. Avalie, nomeie o erro estrutural, reescreva.

## Como aplicar

Leia o pitch inteiro antes de pontuar. Depois percorra os oito critérios, atribuindo 0, 1 ou 2 a cada um. Máximo 16.

Devolva a nota com uma linha de justificativa por critério, citando o trecho do original que causou o desconto. Justificativa sem citação do trecho não ajuda o usuário a aprender o padrão.

Depois da nota, sempre entregue a reescrita. A nota é diagnóstico, a reescrita é o entregável.

---

## Os oito critérios

### 1. Abre pelo cliente (0-2)

- **2**: a primeira frase descreve o mundo do prospect.
- **1**: começa com saudação e vai rápido para o prospect, ou mistura.
- **0**: abre com nome da empresa, credencial, "somos", "trabalho com", "ajudamos empresas a".

### 2. Gatilho ancorado (0-2)

- **2**: contém fato observável da empresa, ou padrão de segmento declarado como padrão.
- **1**: personalização decorativa (elogia post, cita cidade, menciona o nome do CEO) sem consequência de negócio.
- **0**: nenhuma ancoragem, texto serviria para qualquer empresa.

### 3. Silêncio sobre a solução até o empacotamento (0-2)

- **2**: produto, plataforma, metodologia e nome comercial não aparecem antes do pedido de reunião.
- **1**: aparecem de leve, em uma linha.
- **0**: o pitch é uma descrição do que a empresa vende.

### 4. Repertório demonstrado (0-2)

- **2**: menciona mecânica de receita, ineficiência estrutural ou gargalo real daquele modelo de negócio.
- **1**: menciona uma dor genérica que serve para qualquer setor ("otimizar processos", "ganhar produtividade").
- **0**: nenhum sinal de que quem escreveu entende o negócio do outro.

### 5. Pede a reunião, não a compra (0-2)

- **2**: o pedido é uma conversa de diagnóstico, com duração em minutos explicitada.
- **1**: pede reunião mas sem duração, ou com duração vaga ("um café", "papo rápido").
- **0**: pede demonstração, apresentação da plataforma, ou já empurra proposta.

### 6. Entrega antecipada (0-2)

- **2**: está claro o que o prospect leva da conversa mesmo sem comprar (diagnóstico, benchmark, mapa, número).
- **1**: promete valor genérico ("vai ser útil", "insights").
- **0**: o único ganho descrito depende de comprar depois.

### 7. Saída digna (0-2)

- **2**: dá permissão explícita de não seguir, em uma frase natural.
- **1**: sugere sem dizer.
- **0**: pressiona, cria urgência artificial, ou assume o sim.

### 8. Forma adequada ao canal (0-2)

- **2**: dentro do limite do canal, um único próximo passo, legível em uma leitura.
- **1**: um pouco longo, ou com dois pedidos.
- **0**: e-mail de dez linhas para primeiro toque, DM com link, call script de 90 segundos antes do primeiro respiro.

Limites por canal em `canais.md`.

---

## Faixas

- **14 a 16**: pronto para rodar. Sugira apenas variação de teste A/B.
- **10 a 13**: estrutura certa, execução fraca em um ou dois pontos. Reescreva mantendo a espinha.
- **6 a 9**: erro estrutural presente. Reescreva do zero e explique qual etapa da sequência foi pulada.
- **0 a 5**: é apresentação de empresa, não pitch de prospecção. Volte para a fase de pesquisa antes de reescrever.

---

## Diagnóstico por padrão de falha

Identifique qual destes é o erro dominante e nomeie explicitamente. Quase todo pitch ruim cai em um deles.

**Pitch espelho**: o texto fala do vendedor do início ao fim. Sintoma: critérios 1, 3 e 4 baixos juntos. Causa raiz: pulou a fase de pesquisa.

**Pitch de compra disfarçada**: bom começo, mas o pedido é demonstração. Sintoma: critérios 5 e 6 baixos com 1 e 2 altos. Causa raiz: confundiu o objetivo do primeiro contato.

**Pitch decorado**: personalização existe mas é enfeite. Sintoma: critério 2 em 1 e critério 4 em 0. Causa raiz: pesquisou dados em vez de mecânica.

**Pitch sem saída**: tudo certo e o final pressiona. Sintoma: critério 7 em 0. Causa raiz: medo de perder o lead, que produz exatamente a perda.

**Pitch inchado**: conteúdo bom, forma errada para o canal. Sintoma: critério 8 em 0 com o resto alto. Causa raiz: escreveu uma vez e reaproveitou em todos os canais.

**Pitch fantasioso**: afirma sobre a empresa o que não dá para saber de fora. Sintoma: critério 2 aparentemente forte, mas insustentável. Trate como falha grave e sinalize separado da nota: não sobrevive à primeira réplica e queima o contato.

---

## Formato de devolutiva

```
Nota: X/16

Por critério:
1. Abre pelo cliente: X/2. [justificativa citando trecho]
...

Erro estrutural: [nome do padrão de falha e por que ele acontece]

Reescrita:
[versão nova, mesmo canal]

O que testar primeiro:
[uma variável isolada, com a hipótese por trás]
```

Se o usuário colou uma sequência inteira, audite cada toque separadamente e depois avalie a sequência como conjunto: os toques repetem o mesmo ângulo? Cada um adiciona algo novo? O último toque dá saída limpa?

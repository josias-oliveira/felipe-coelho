# Pesquisa e repertório

Roteiro de investigação antes de escrever qualquer pitch. Objetivo: sair com material suficiente para falar do negócio do prospect sem falar da própria solução.

## Índice

1. As seis perguntas
2. Fontes e o que cada uma revela
3. Gargalos típicos por modelo de negócio
4. Gargalos típicos por porte
5. Sinais de evento observável
6. O que fazer quando a pesquisa vem vazia

---

## 1. As seis perguntas

Responda antes de escrever. Se três ou mais ficarem em branco, o pitch vai sair genérico.

**Como ganham dinheiro.** Linha de receita principal, ticket médio provável, recorrência ou transação, quem assina o contrato. Uma empresa que vive de contrato anual enterprise tem problema diferente de uma que vive de volume transacional.

**Qual o motor de crescimento.** Inside sales, vendas de campo, PLG, canal/parceria, franquia, varejo físico, marketplace, licitação pública. O motor define quais gargalos são possíveis e quais não fazem sentido mencionar.

**Onde o modelo vaza.** Custos e perdas estruturais daquele modelo: CAC acima do payback, churn na base, ociosidade de time técnico, retrabalho de operação manual, estoque parado, inadimplência, concentração em poucos clientes, dependência de um canal só.

**Qual o gargalo típico do porte e do segmento.** Este é o que permite abrir conversa com empresa que você não conhece por dentro. Empresas parecidas travam nos mesmos pontos.

**Qual evento está acontecendo agora.** Ver seção 5.

**Quem é o dono da dor.** Cargo, métrica que ele defende, número pelo qual é cobrado, e o que acontece com ele se esse número não bater. O pitch fala com a métrica dessa pessoa, não com a da empresa em abstrato.

---

## 2. Fontes e o que cada uma revela

| Fonte | O que revela |
|---|---|
| Página de preços | Modelo de monetização, ticket, segmentação de plano, se vendem self-service ou por contato comercial |
| Vagas abertas | Prioridade real de investimento, tamanho do time comercial, stack técnico, cargos novos que indicam nova frente |
| LinkedIn da empresa (crescimento de headcount) | Ritmo de expansão e em qual área |
| LinkedIn do decisor | Tempo de casa, o que ele publica, de onde veio, o que ele considera problema |
| Blog e materiais ricos | Qual dor eles acham que o mercado tem, o que estão tentando comunicar |
| Releases e notícias | Rodada, aquisição, expansão, troca de liderança |
| Relatórios de RI (se listada) | Números reais de receita, margem, CAC, churn, e a narrativa que a empresa conta ao mercado |
| Reclame Aqui e reviews de app/produto | Onde a operação quebra na ponta, com texto de cliente real |
| Podcast ou entrevista do fundador | Prioridade declarada e linguagem interna da empresa |
| Perfil de anúncios (biblioteca de anúncios) | Onde estão apostando aquisição e com qual promessa |
| Site de emprego (Glassdoor e similares) | Atrito interno, rotatividade, o que o time reclama |

Duas ou três fontes bem lidas valem mais que dez superficiais. Vagas abertas e página de preços costumam ser as de maior densidade por minuto investido.

---

## 3. Gargalos típicos por modelo de negócio

Use como hipótese de partida, sempre apresentada como padrão de segmento e nunca como afirmação sobre a empresa.

**SaaS B2B recorrente**: CAC subindo mais rápido que o ticket, churn concentrado nos primeiros 90 dias, expansão dependente de upsell manual, time de vendas com performance muito desigual entre reps.

**Serviço e consultoria**: receita presa à agenda dos sócios, margem corroída por retrabalho e escopo aberto, pipeline dependente de indicação, dificuldade de precificar por valor.

**Indústria e distribuição**: capital preso em estoque, previsão de demanda ruim, mix de produto com margens muito diferentes, força de vendas com pouca visibilidade de rentabilidade por pedido.

**Varejo e e-commerce**: dependência de mídia paga, margem de contribuição apertada, recompra baixa, logística reversa cara.

**Marketplace**: desequilíbrio entre os dois lados, take rate sob pressão, desintermediação depois do primeiro match.

**Educação**: custo de aquisição de aluno alto, evasão ao longo do curso, receita concentrada em picos de matrícula.

**Saúde**: glosa e faturamento, ocupação de agenda, absenteísmo de paciente, integração de sistemas.

**Agência**: dependência de poucos clientes grandes, hora vendida abaixo do custo real, rotatividade de time.

---

## 4. Gargalos típicos por porte

**Até 10 pessoas**: fundador é o comercial, processo não existe, decisão rápida mas orçamento apertado.

**10 a 50**: primeiro time comercial contratado, resultado depende de duas ou três pessoas, sem processo replicável, previsibilidade próxima de zero.

**50 a 200**: transição de vendas fundador-dependente para vendas de time. Aparecem os problemas de onboarding de rep, ramp-up longo, disputa entre marketing e vendas sobre qualidade de lead.

**200 a 1000**: complexidade de governança, silos entre áreas, ferramentas duplicadas, dado espalhado, ciclo de decisão longo e com comitê.

**Acima de 1000**: compras e jurídico como gargalo real, prova de conceito obrigatória, necessidade de sponsor interno forte, integração com legado.

A transição entre faixas é o momento de maior abertura para conversa, porque a empresa acabou de descobrir que o que funcionava parou de funcionar.

---

## 5. Sinais de evento observável

Ordenados por força do sinal:

1. Contratação concentrada de um cargo específico (cinco vagas de SDR indica aposta em outbound).
2. Rodada de investimento ou aquisição recente.
3. Troca de liderança na área que você quer atingir. Executivo novo tem 90 dias para mostrar mudança.
4. Expansão geográfica ou entrada em novo segmento de cliente.
5. Lançamento de produto ou de linha nova.
6. Mudança regulatória que afeta o setor.
7. Migração tecnológica visível (mudança de stack detectável, novo site, nova plataforma de e-commerce).
8. Movimentação forte de concorrente direto.

Um sinal recente e específico vence dez fatos genéricos.

---

## 6. O que fazer quando a pesquisa vem vazia

Empresa fechada, sem site relevante, sem presença pública. Três saídas, nesta ordem:

1. **Suba um nível**: use padrão de segmento e porte em vez de fato da empresa. O gatilho de padrão de segmento existe exatamente para isso.
2. **Use o par**: cite o que você viu em empresas do mesmo perfil, o que é verdadeiro e verificável do seu lado.
3. **Peça o fato ao usuário**: ele frequentemente sabe algo que não está público (veio de indicação, conhece o mercado, já atendeu concorrente).

Nunca preencha a lacuna com invenção. Um número falso destrói o pitch na primeira réplica do prospect, e ele lembra.

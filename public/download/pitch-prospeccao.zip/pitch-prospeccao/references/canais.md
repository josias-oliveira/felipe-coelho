# Canais e sequência

A estrutura gatilho + empacotamento não muda entre canais. O que muda é o tempo de atenção disponível e a forma.

## Limites por canal

| Canal | Tamanho alvo | Gatilho até | Observações |
|---|---|---|---|
| Cold call | 35 a 50 segundos de fala até a primeira pausa | 15 segundos | O prospect decide nos primeiros dez. Nada de "tudo bem?" antes do gatilho |
| Cold e-mail (1º toque) | 70 a 110 palavras | 1ª frase | Sem imagem, sem assinatura carregada, sem link no primeiro toque |
| DM de LinkedIn | 45 a 70 palavras | 1ª frase | Sem link, sem anexo. Link no primeiro toque derruba entrega e resposta |
| WhatsApp | 40 a 60 palavras | 1ª frase | Só depois de contato prévio ou opt-in. Frio puro queima o número |
| Áudio ou voicemail | 20 a 25 segundos | 8 segundos | Termine dizendo que vai mandar o horário por escrito |
| Vídeo curto | 45 a 60 segundos | 10 segundos | O gatilho precisa estar na miniatura ou na primeira frase |

## Assunto de e-mail

Três a seis palavras, minúsculas, sem promessa e sem verbo de venda. O assunto nomeia o tema, não o benefício.

Bons: `mix de produto e margem`, `ramp-up de rep novo`, `reativação de base`, `glosa em faturamento`.

Ruins: `Aumente suas vendas em 40%`, `Oportunidade para a [empresa]`, `Parceria estratégica`, `Vamos conversar?`.

Sem RE: ou FWD: falsos. Isso funciona uma vez e destrói a relação depois.

## Ritmo de sequência

Sete a nove toques em três a quatro semanas, alternando canais. A regra central: **cada toque traz um ângulo novo**, nunca um lembrete do anterior. "Só dando um follow-up" é toque desperdiçado.

Desenho base:

1. **Dia 1, e-mail**: gatilho de movimento ou padrão, empacotamento de diagnóstico.
2. **Dia 2, ligação**: mesmo gatilho, versão falada. Ligar depois do e-mail, não antes.
3. **Dia 4, LinkedIn**: convite de conexão sem texto de venda, ou DM com ângulo diferente.
4. **Dia 7, e-mail**: ângulo novo, normalmente o cálculo de perda ou o benchmark.
5. **Dia 9, ligação**: em outro horário do dia.
6. **Dia 14, e-mail**: prova social específica do segmento, curta.
7. **Dia 18, ligação**.
8. **Dia 22, e-mail de encerramento**: uma linha, sem culpa, sem ironia, deixando a porta aberta e pedindo apenas a informação de timing.

O e-mail de encerramento costuma ter a maior taxa de resposta da sequência. Escreva com cuidado e sem passivo-agressividade.

## Multithread

Em venda enterprise, aborde dois ou três cargos da mesma conta em paralelo, com ângulos diferentes. O gatilho é o mesmo, o empacotamento muda porque a métrica defendida muda.

Exemplo, mesma conta:

- **CFO**: empacotamento de cálculo de perda.
- **Diretor comercial**: empacotamento de benchmark de segmento.
- **Head de operações**: empacotamento de teardown do fluxo atual.

Nunca finja que não está falando com outras pessoas da mesma empresa. Se aparecer, trate com naturalidade.

## Sinais de que a sequência está errada

- Taxa de abertura alta e resposta perto de zero: o assunto funciona e o corpo não. Problema no gatilho ou no empacotamento.
- Abertura baixa: problema de assunto, de entregabilidade ou de lista.
- Resposta com "manda mais informações" que nunca evolui: o empacotamento não tinha compromisso curto e nomeado.
- Reunião marcada e no-show alto: o valor prometido era vago, ou o compromisso foi aceito por educação.
- Reunião acontece e não evolui: o problema saiu da prospecção e foi para o diagnóstico. Prospecção fez o trabalho dela.

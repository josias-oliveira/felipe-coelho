# Biblioteca de gatilhos e empacotamentos

Modelos com exemplos completos. Use como estrutura, não como texto pronto: todo exemplo aqui precisa receber o fato específico do prospect antes de ir para a rua.

## Índice

1. Cinco formatos de gatilho
2. Cinco formatos de empacotamento
3. Pitches completos por contexto
4. Antes e depois
5. Fechamentos que funcionam e fechamentos que matam
6. Respostas às objeções mais comuns

---

## 1. Cinco formatos de gatilho

### Movimento

Ancora em evento observável. É o mais forte quando o evento é recente e específico.

> "Vi que vocês abriram cinco posições de vendas em dois meses e estão estruturando a operação para atender contas maiores."

> "Acompanhei o anúncio da entrada de vocês no Nordeste no trimestre passado."

Cuidado: citar o evento sem conectar a uma consequência de negócio vira elogio vazio. O evento precisa apontar para um problema previsível.

### Padrão de segmento

Ancora na sua conversa com pares. Funciona quando a pesquisa sobre a empresa específica veio pobre.

> "Tenho conversado com operações de distribuição do mesmo porte que a de vocês e apareceu um padrão consistente na forma como o mix de produto afeta a margem por pedido."

> "Nos últimos meses falei com uns quinze times comerciais de SaaS que passaram de 50 para 200 pessoas, e três coisas se repetiram em quase todos."

Regra: só use se for verdade. Se você não conversou com essas empresas, use o formato de estágio.

### Estágio

Ancora na transição de porte ou de maturidade. Não exige nenhum dado privilegiado.

> "Empresas que saem de venda liderada pelo fundador para venda de time costumam travar no mesmo ponto: o ramp-up do rep novo passa de seis meses e a previsibilidade cai."

### Mecânica de receita

Prova repertório mostrando que você entendeu como eles ganham dinheiro. É o mais difícil de fazer e o que mais impressiona decisor sênior.

> "No modelo de vocês a receita depende muito mais da taxa de reativação da base do que da aquisição nova, e é justamente aí que a maior parte das operações parecidas tem menos instrumentação."

### Contradição observável

Aponta um dado público que não fecha. Alto risco e alto retorno. Use com C-level, evite com gerência média.

> "Vocês comunicam autoatendimento como diferencial, mas as cinco posições abertas são de suporte humano. Isso costuma indicar um ponto específico do fluxo que ainda não fecha sozinho."

Nunca formule como acusação ou pegadinha. A leitura tem que ser de alguém que estudou, não de alguém que quer marcar ponto.

---

## 2. Cinco formatos de empacotamento

Todos precisam dos quatro ingredientes: entrega antecipada, compromisso curto e nomeado, saída digna, próximo passo único.

### Diagnóstico de padrões

> "Queria te mostrar três padrões que encontramos analisando operações parecidas com a de vocês e onde normalmente aparece espaço para aumentar receita ou cortar desperdício. São 25 minutos. Se ao final não fizer sentido seguir, você sai com o diagnóstico e algumas ideias aplicáveis internamente."

### Benchmark de segmento

> "Consolidamos como oito empresas do seu segmento resolveram isso, com o que funcionou e o que custou caro. Em 20 minutos consigo te mostrar onde a operação de vocês se posiciona nesse recorte."

Só use se o benchmark existir de fato.

### Mapa de gargalos por estágio

> "Tenho um mapa dos gargalos que aparecem em cada estágio dessa transição, com o sintoma que antecede cada um. Em meia hora dá para marcar onde vocês estão e o que costuma vir depois."

### Teardown do que já existe

> "Posso revisar o fluxo atual de vocês e apontar onde a conversão cai, ponto a ponto. São 30 minutos e o material fica com você, usando ou não."

Forte porque a entrega é sobre o ativo do prospect, não sobre um material genérico seu.

### Cálculo de perda

> "Em 20 minutos consigo dimensionar com você quanto essa ineficiência custa por mês na operação de vocês. Mesmo que você não faça nada com isso agora, o número em si já muda a conversa interna."

Exige que o usuário tenha um modelo de cálculo real. Sem isso, vira promessa vazia.

---

## 3. Pitches completos por contexto

### Cold call, SaaS B2B em escala

> "Josias, aqui é o [nome]. Vi que vocês passaram de 60 para 140 pessoas no último ano e abriram três vagas de vendas nesse período. Empresas nessa transição costumam esbarrar em três gargalos comerciais que limitam a escala, e eles quase nunca aparecem no CRM antes de virar problema de receita. Queria te mostrar esse diagnóstico e como outras empresas do mesmo estágio lidaram com isso. São 25 minutos. Se não fizer sentido evoluir para uma conversa comercial, você sai entendendo o grau de dificuldade de implementar o que já foi feito por outras operações. Faz mais sentido quinta de manhã ou sexta à tarde?"

### Cold e-mail, indústria

> **Assunto:** mix de produto e margem por pedido
>
> "[Nome], tenho conversado com distribuidoras do porte da [empresa] e apareceu um padrão: o mix vendido pela força de campo tende a puxar volume, não margem, e isso só fica visível no fechamento do mês.
>
> Consolidei como quatro operações parecidas passaram a enxergar rentabilidade por pedido no momento da venda, com o que funcionou e o que custou caro.
>
> São 20 minutos. Se não fizer sentido seguir, o material fica com você.
>
> Vale uma conversa na próxima semana?"

### DM de LinkedIn, consultoria para serviços

> "[Nome], vi que a [empresa] está estruturando a operação para atender contas maiores. Nessa transição a receita costuma continuar presa à agenda dos sócios, e o efeito aparece na margem antes de aparecer no faturamento. Tenho um mapa dos gargalos dessa fase. Consigo te mostrar em 20 minutos, e ele fica com você independentemente do que decidirmos. Posso te chamar essa semana?"

### Áudio ou voicemail, 20 segundos

> "[Nome], é o [nome] da [empresa]. Ligo por causa de um padrão que tenho visto em operações do seu porte, que afeta previsibilidade de receita. Tenho um diagnóstico curto para te mostrar, 20 minutos, e ele é útil mesmo que a gente não siga. Te mando a proposta de horário por e-mail."

---

## 4. Antes e depois

**Antes**
> "Somos especialistas em vendas consultivas e gostaríamos de apresentar nossa metodologia. Você tem 15 minutos para conhecer nossa plataforma?"

Problemas: abre pelo vendedor, credencial autoproclamada, o pedido é compromisso de compra disfarçado, o prospect não ganha nada por aceitar.

**Depois**
> "Percebi que a empresa está acelerando o crescimento. Empresas nesse momento costumam ter três gargalos comerciais que limitam a escala. Queria compartilhar esse diagnóstico e mostrar como outras empresas parecidas encararam esses desafios. Mesmo que a gente não evolua para uma conversa comercial, você sai entendendo o grau de dificuldade de implementar algo que já foi feito por várias operações."

---

**Antes**
> "Vi seu post sobre liderança, muito bom! Trabalho com uma solução que ajuda empresas como a sua a economizar tempo. Podemos marcar um café?"

Problemas: personalização decorativa, benefício genérico, compromisso sem forma nem duração.

**Depois**
> "Vi que vocês estruturaram um time de customer success neste semestre. Nas operações que fazem esse movimento, o gargalo migra rápido do onboarding para a expansão de conta, e quase sempre sem instrumentação para enxergar isso. Tenho três padrões mapeados sobre onde essa receita se perde. São 20 minutos e o material fica com você. Terça às 10h funciona?"

---

## 5. Fechamentos que funcionam e fechamentos que matam

**Matam** (a resposta padrão é não):

- "Faz sentido conversarmos?"
- "Você teria interesse?"
- "Podemos agendar um bate-papo rápido?"
- "Fico à disposição."
- "Aguardo seu retorno."

**Funcionam** (a resposta padrão é uma escolha):

- "Terça às 10h ou quinta às 16h?"
- "Te mando o convite para quinta de manhã?"
- "Se preferir, te mando o diagnóstico por escrito antes e você decide se vale a conversa."
- "Quem além de você olharia esse número?"

O último transforma um não em informação útil sobre a estrutura de decisão.

---

## 6. Respostas às objeções mais comuns

**"Não tenho interesse."**
> "Entendi. Só para eu calibrar a lista: o tema não é prioridade agora ou vocês já resolveram esse ponto internamente?"

**"Manda por e-mail."**
> "Mando. Para o e-mail não virar mais um genérico, me diz uma coisa: hoje o que mais te incomoda nesse processo é [A] ou [B]?"

**"Já temos fornecedor."**
> "Imaginei. A conversa não é de troca. É sobre um recorte que costuma ficar fora do escopo desse tipo de contrato. Se depois de 20 minutos você achar que já está coberto, encerramos."

**"Estamos sem orçamento."**
> "Faz sentido. A proposta agora não envolve orçamento nenhum, é dimensionar o tamanho do problema. Se o número for pequeno, você economiza o tempo de olhar isso de novo no ano que vem."

**"Manda uma proposta."** (cedo demais)
> "Consigo, mas ela sairia genérica e você ia descartar com razão. Me dá 20 minutos para entender o contexto e a proposta chega com número seu dentro."

**"Quem é você mesmo?"**
> "Justo. [Uma frase de contexto real, sem superlativo.] Mas o motivo da ligação é o padrão que citei, não a apresentação da empresa."
